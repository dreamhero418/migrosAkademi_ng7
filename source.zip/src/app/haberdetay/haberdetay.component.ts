import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-haberdetay',
  templateUrl: './haberdetay.component.html',
  styleUrls: ['./haberdetay.component.scss']
})
export class HaberdetayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
